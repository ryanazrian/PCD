from sklearn.ensemble import RandomForestRegressor 
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import confusion_matrix 

import pandas as pd 
import numpy as np 

import pickle

import matplotlib.pyplot as plt


#ambil data dari csv
data = pd.read_csv('tomat.csv') 

#manipulasi data untuk dicoba kan (Test)
dataCoba = data.drop(["Class"], axis=1)
dataCoba = dataCoba.drop(["Pixel"], axis=1)
dataCoba = dataCoba.drop(["Berat"], axis=1)
dataCoba = dataCoba.drop(["Lebar"], axis=1)
dataCoba1 = data["Class"]

#Untuk prediksi berat (Regresi)
dataBerat = data[['Pixel', 'Lebar']]
dataBerat1 = data["Berat"]

print(dataCoba)
print(dataBerat)

#Pembuatan Model
modelMatang = MLPClassifier(activation='relu', alpha=1e-05, batch_size='auto', beta_1=0.9, beta_2=0.999, early_stopping=False, epsilon=1e-08, hidden_layer_sizes=(30, 20 ), learning_rate='constant', learning_rate_init=0.001, max_iter=1000000, momentum=0.9, nesterovs_momentum=True, power_t=0.5, random_state=1, shuffle=True, solver='lbfgs', tol=0.0001, validation_fraction=0.1, verbose=False, warm_start=False)
modelMatang.fit(dataCoba, dataCoba1)

modelBerat = RandomForestRegressor() 
modelBerat.fit(dataBerat,dataBerat1) 


#Prediksi
matangPredict = modelMatang.predict(dataCoba)
beratPredict = modelBerat.predict(dataBerat)

print(matangPredict)
print(beratPredict)

cnf_matrix = confusion_matrix(dataCoba1, matangPredict)
print(cnf_matrix) 

#Simpan Model
filename = 'kematangan.sav' 
pickle.dump(modelMatang, open(filename, 'wb')) 

filename = 'berat.sav' 
pickle.dump(modelBerat, open(filename, 'wb')) 

# Plot non-normalized confusion matrix
plt.figure()
plt.imshow(cnf_matrix, interpolation='nearest')
plt.show()